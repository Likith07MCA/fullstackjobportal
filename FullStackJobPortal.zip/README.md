# Full Stack Job Portal

A student/recruiter job portal built with React, Vite, Node.js, Express, and MongoDB.

## Requirements
- Node.js 20.19+ or 22.12+
- MongoDB Community Server running locally, or a MongoDB Atlas URI

## Setup

### 1. Backend
```powershell
cd backend
Copy-Item .env.example .env
npm install
npm run dev
```
Edit `backend/.env` if your MongoDB URI differs. Default local URI: `mongodb://127.0.0.1:27017/fullstack_job_portal`.

### 2. Frontend (new terminal)
```powershell
cd web
npm install
npm run dev
```
Open the Vite URL printed in the terminal, usually http://localhost:5173.

## Demo workflow
1. Register one account with role `Student`.
2. Register a second account with role `Recruiter`.
3. Log in as recruiter and post a job.
4. Log in as student and apply for the job.
5. Log in as recruiter and view/update the application status.

## API overview
- `POST /api/auth/register`, `POST /api/auth/login`, `GET /api/auth/me`
- `GET /api/profile`, `PUT /api/profile`
- `GET /api/jobs`, `GET /api/jobs/:id`, `POST /api/jobs`, `PUT /api/jobs/:id`, `DELETE /api/jobs/:id`
- `POST /api/applications`, `GET /api/applications/mine`, `GET /api/applications/received`, `PATCH /api/applications/:id/status`

Protected endpoints require `Authorization: Bearer <token>`.
